import random
continuar = True
mao2 = [None]*9
for i in range (0,9):
    mao2[i] = [None]*6

maos = {'Jorge':1, 'Matheus':2, 'Lucas':3, 'Bruno': 4, 'Yasmin': 5,
        "Pedro": 6, 'Guilherme': 7, 'Rebeca': 8, 'Laura':9}
cartas = ('A', '2','3','4','5','6','7','8','9','10','J','Q','K')
naipe = ('Zap', 'Copas','Espada', 'Ouros')
embaralhar = [(k,j)for k in cartas for j in naipe]
random.shuffle(embaralhar)
x = 0

while x < 51:
    for i in range (0,6):
        for j in range (0,9):
            mao2[j][i] = embaralhar[x]
            x += 1
            if x == 52:
                break
            
while continuar:
    print ('==============================')
    print (' ')
    print ('As Cartas Foram distribuidas!! ')
    print ('1 - Consultar uma mão ')
    print ('2 - Sair')
    print ('')
    print('==============================')
    escolha = input('O que você deseja fazer? ')
    if escolha == '1':
        print ('Escolha Qual mão você deseja ver!! ')
        print ('Jorge, Matheus, Lucas, Bruno, Yasmin, Pedro, Guilherme, Rebeca ou Laura')
        z = input()
        if z in maos:
            print (mao2[maos[z]-1])
        else:
            print ('Nome invalido! ')


    elif escolha == '2':
        continuar = False
    else :
        print ('Entrada Invalida! ')


